package com.aluracursos.screenmatch_frases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScreenmatchFrasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScreenmatchFrasesApplication.class, args);
	}

}
