package com.aluracursos.literalura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
